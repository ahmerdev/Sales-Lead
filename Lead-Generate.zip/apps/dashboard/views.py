from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from apps.leads.models import Lead
from apps.ai_engine.models import AIPitch
from apps.scanner.models import WebsiteAudit

@login_required
def index_view(request):
    workspace_owner = request.user
    leads = Lead.objects.filter(workspace__owner=workspace_owner)

    total_leads = leads.count()
    high_opps = leads.filter(opportunity_level='HIGH').count()
    contacted_count = leads.filter(status='CONTACTED').count()
    replies_count = leads.filter(status='REPLIED').count()
    interested_count = leads.filter(status='INTERESTED').count()
    won_count = leads.filter(status='WON').count()

    # Pipeline counts
    pipeline = {
        'new': leads.filter(status='NEW').count(),
        'contacted': contacted_count,
        'replied': replies_count,
        'interested': interested_count,
        'proposal': leads.filter(status='PROPOSAL').count(),
        'won': won_count,
    }

    recent_leads = leads.order_by('-created_at')[:8]
    recent_audits = WebsiteAudit.objects.filter(lead__workspace__owner=workspace_owner).order_by('-scanned_at')[:5]

    context = {
        'total_leads': total_leads,
        'high_opps': high_opps,
        'contacted_count': contacted_count,
        'replies_count': replies_count,
        'interested_count': interested_count,
        'won_count': won_count,
        'pipeline': pipeline,
        'recent_leads': recent_leads,
        'recent_audits': recent_audits,
    }
    return render(request, 'dashboard/index.html', context)
