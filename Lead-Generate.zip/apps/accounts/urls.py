from django.urls import path
from . import views

app_name = 'accounts'

urlpatterns = [
    path('profile/', views.profile_view, name='profile'),
    path('settings/', views.settings_view, name='settings'),
    path('workspace/switch/<int:workspace_id>/', views.switch_workspace_view, name='switch_workspace'),
]
