from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.urls import reverse
from .models import User, Workspace, WorkspaceMember
from django.contrib.auth import update_session_auth_hash
from .forms import (
    UserRegistrationForm, UserLoginForm, UserProfileForm, EmailSettingsForm, WhatsAppSettingsForm,
    ApiSettingsForm, AgencySettingsForm, StyledPasswordChangeForm,
)
from .services import get_user_settings, send_user_email, MailerError, portfolio_link, public_url, is_local_link

def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard:index')

    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            username = email.split('@')[0]
            # Ensure unique username
            base_username = username
            counter = 1
            while User.objects.filter(username=username).exists():
                username = f"{base_username}{counter}"
                counter += 1

            user = User.objects.create_user(
                username=username,
                email=email,
                password=form.cleaned_data['password'],
                full_name=form.cleaned_data['full_name'],
                role='admin'
            )

            # Create default workspace
            workspace_name = f"{user.full_name or username}'s Agency"
            workspace = Workspace.objects.create(
                name=workspace_name,
                owner=user,
                plan='pro'
            )
            WorkspaceMember.objects.create(workspace=workspace, user=user, role='owner')

            login(request, user)
            request.session['active_workspace_id'] = workspace.id
            messages.success(request, f"Welcome to LeadRadar AI, {user.full_name or user.username}!")
            return redirect('dashboard:index')
    else:
        form = UserRegistrationForm()

    return render(request, 'auth/register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard:index')

    if request.method == 'POST':
        form = UserLoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']

            # The custom User model logs in with EMAIL (USERNAME_FIELD = 'email'), so Django's
            # backend must receive the email, not the username. Match email case-insensitively.
            user_obj = User.objects.filter(email__iexact=email.strip()).first()
            if user_obj:
                user = authenticate(request, username=user_obj.email, password=password)
                if user is not None:
                    login(request, user)
                    messages.success(request, f"Welcome back, {user.full_name or user.username}!")
                    return redirect('dashboard:index')
            
            messages.error(request, "Invalid email or password.")
    else:
        form = UserLoginForm()

    return render(request, 'auth/login.html', {'form': form})


def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('login')


@login_required
def profile_view(request):
    # Profile now lives inside the Settings page.
    return redirect(f"{reverse('accounts:settings')}?tab=profile")


SETTINGS_TABS = ('profile', 'email', 'whatsapp', 'api', 'agency', 'security')


@login_required
def settings_view(request):
    user = request.user
    s = get_user_settings(user)
    workspace = Workspace.objects.filter(owner=user).first()
    tab = request.GET.get('tab') or request.POST.get('tab') or 'profile'
    if tab not in SETTINGS_TABS:
        tab = 'profile'

    forms_by_tab = {
        'profile': UserProfileForm(instance=user),
        'email': EmailSettingsForm(instance=s),
        'whatsapp': WhatsAppSettingsForm(instance=s),
        'api': ApiSettingsForm(),
        'agency': AgencySettingsForm(instance=s),
        'security': StyledPasswordChangeForm(user),
    }

    if request.method == 'POST':
        section = request.POST.get('section', tab)
        if section not in SETTINGS_TABS:
            section = 'profile'
        tab = section

        if section == 'profile':
            form = UserProfileForm(request.POST, instance=user)
        elif section == 'email':
            form = EmailSettingsForm(request.POST, instance=s)
        elif section == 'whatsapp':
            form = WhatsAppSettingsForm(request.POST, instance=s)
        elif section == 'api':
            form = ApiSettingsForm(request.POST)
        elif section == 'agency':
            form = AgencySettingsForm(request.POST, instance=s)
        else:
            form = StyledPasswordChangeForm(user, request.POST)

        if form.is_valid():
            if section == 'api':
                if form.cleaned_data.get('clear_gemini'):
                    s.gemini_api_key = ''
                    messages.success(request, "Your Gemini API key was removed.")
                elif form.cleaned_data.get('gemini_api_key'):
                    s.gemini_api_key = form.cleaned_data['gemini_api_key'].strip()
                    messages.success(request, "Gemini API key saved. AI pitches will now use your key.")
                else:
                    messages.info(request, "Nothing changed.")
                s.save()
            elif section == 'security':
                user = form.save()
                update_session_auth_hash(request, user)
                messages.success(request, "Password changed successfully.")
            else:
                form.save()
                messages.success(request, "Settings saved.")

            if section == 'email' and 'send_test' in request.POST:
                try:
                    send_user_email(
                        request.user, request.user.email,
                        "Test email from LeadRadar AI",
                        "Great news: your mailbox is connected. Pitches and proposals you send from LeadRadar "
                        "will now go out from this address.",
                    )
                    messages.success(request, f"Test email sent to {request.user.email}. Check your inbox.")
                except MailerError as exc:
                    messages.error(request, str(exc))
            return redirect(f"{request.path}?tab={section}")

        forms_by_tab[section] = form

    context = {
        'tab': tab,
        'profile_form': forms_by_tab['profile'],
        'email_form': forms_by_tab['email'],
        'whatsapp_form': forms_by_tab['whatsapp'],
        'api_form': forms_by_tab['api'],
        'agency_form': forms_by_tab['agency'],
        'security_form': forms_by_tab['security'],
        'settings_obj': s,
        'workspace': workspace,
        'portfolio_url': public_url(request, user, reverse('public_portfolio', args=[workspace.slug])) if workspace else '',
        'local_link_warning': is_local_link(request, user),
    }
    return render(request, 'auth/settings.html', context)


@login_required
def switch_workspace_view(request, workspace_id):
    workspace = get_object_or_404(Workspace, id=workspace_id)
    if workspace.owner == request.user or WorkspaceMember.objects.filter(workspace=workspace, user=request.user).exists():
        request.session['active_workspace_id'] = workspace.id
        messages.success(request, f"Switched workspace to {workspace.name}")
    else:
        messages.error(request, "You do not have access to that workspace.")
    return redirect('dashboard:index')
