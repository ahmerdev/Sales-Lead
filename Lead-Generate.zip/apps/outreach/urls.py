from django.urls import path
from . import views

app_name = 'outreach'

urlpatterns = [
    path('', views.campaigns_list_view, name='campaigns'),
    path('inbox/', views.communications_inbox_view, name='inbox'),
    path('new/', views.campaign_create_view, name='create_campaign'),
    path('<int:pk>/', views.campaign_detail_view, name='detail'),
    path('<int:campaign_id>/sent/<int:lead_id>/', views.mark_campaign_lead_sent_view, name='mark_sent'),

    # Direct messaging & Inbound reply tracking
    path('lead/<int:lead_id>/send-email/', views.send_direct_email_view, name='send_email'),
    path('lead/<int:lead_id>/send-whatsapp/', views.send_direct_whatsapp_view, name='send_whatsapp'),
    path('lead/<int:lead_id>/log-reply/', views.log_inbound_reply_view, name='log_reply'),
]
