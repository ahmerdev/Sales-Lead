from django.urls import path
from . import views

app_name = 'portfolio'

urlpatterns = [
    path('', views.portfolio_list_view, name='list'),
    path('add/', views.portfolio_create_view, name='create'),
    path('<int:pk>/edit/', views.portfolio_update_view, name='update'),
    path('<int:pk>/delete/', views.portfolio_delete_view, name='delete'),
]
