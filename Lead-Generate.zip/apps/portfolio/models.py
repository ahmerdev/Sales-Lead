from django.db import models
from apps.accounts.models import Workspace


class PortfolioItem(models.Model):
    """One live project the agency shows to prospects to build trust."""
    workspace = models.ForeignKey(Workspace, on_delete=models.CASCADE, related_name='portfolio_items')
    title = models.CharField(max_length=200, help_text='e.g. "Online ordering website for Saffron Bistro"')
    client_name = models.CharField(max_length=200, blank=True)
    industry = models.CharField(max_length=100, blank=True, help_text='e.g. Restaurant, Dental, Real Estate')
    live_url = models.URLField(blank=True, help_text='Link to the live website so the client can open it')
    image = models.FileField(upload_to='portfolio/', blank=True, help_text='Screenshot of the project (PNG/JPG)')
    image_url = models.URLField(blank=True, help_text='Or paste an image link instead of uploading')
    description = models.TextField(blank=True)
    results = models.CharField(max_length=255, blank=True, help_text='A real result, e.g. "+40% direct orders in 3 months"')
    testimonial = models.TextField(blank=True, help_text='Only add real client feedback')
    testimonial_author = models.CharField(max_length=150, blank=True)
    is_published = models.BooleanField(default=True)
    sort_order = models.PositiveIntegerField(default=0, help_text='Lower numbers appear first')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['sort_order', '-created_at']

    def __str__(self):
        return self.title

    @property
    def cover(self):
        if self.image:
            return self.image.url
        return self.image_url
