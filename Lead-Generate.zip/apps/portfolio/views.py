from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import Http404
from django.urls import reverse
from apps.accounts.models import Workspace
from apps.accounts.services import get_user_settings, public_url, is_local_link, whatsapp_link
from .models import PortfolioItem
from .forms import PortfolioItemForm


def _workspace(request):
    ws_id = request.session.get('active_workspace_id')
    ws = Workspace.objects.filter(id=ws_id, owner=request.user).first() if ws_id else None
    return ws or Workspace.objects.filter(owner=request.user).first() or Workspace.objects.create(
        name=f"{request.user.full_name or request.user.username}'s Agency", owner=request.user)


@login_required
def portfolio_list_view(request):
    ws = _workspace(request)
    items = PortfolioItem.objects.filter(workspace=ws)
    s = get_user_settings(request.user)
    return render(request, 'portfolio/list.html', {
        'items': items,
        'public_link': public_url(request, request.user, reverse('public_portfolio', args=[ws.slug])),
        'portfolio_enabled': s.portfolio_enabled,
        'local_link_warning': is_local_link(request, request.user),
    })


@login_required
def portfolio_create_view(request):
    ws = _workspace(request)
    if request.method == 'POST':
        form = PortfolioItemForm(request.POST, request.FILES)
        if form.is_valid():
            item = form.save(commit=False)
            item.workspace = ws
            item.save()
            messages.success(request, f"'{item.title}' added to your portfolio.")
            return redirect('portfolio:list')
    else:
        form = PortfolioItemForm()
    return render(request, 'portfolio/form.html', {'form': form, 'title': 'Add Portfolio Project'})


@login_required
def portfolio_update_view(request, pk):
    item = get_object_or_404(PortfolioItem, pk=pk, workspace__owner=request.user)
    if request.method == 'POST':
        form = PortfolioItemForm(request.POST, request.FILES, instance=item)
        if form.is_valid():
            form.save()
            messages.success(request, "Portfolio project updated.")
            return redirect('portfolio:list')
    else:
        form = PortfolioItemForm(instance=item)
    return render(request, 'portfolio/form.html', {'form': form, 'item': item, 'title': 'Edit Portfolio Project'})


@login_required
def portfolio_delete_view(request, pk):
    item = get_object_or_404(PortfolioItem, pk=pk, workspace__owner=request.user)
    if request.method == 'POST':
        item.delete()
        messages.success(request, "Portfolio project deleted.")
    return redirect('portfolio:list')


def public_portfolio_view(request, slug):
    """Public page a prospect opens from your email / WhatsApp / proposal. No login needed."""
    workspace = get_object_or_404(Workspace, slug=slug)
    owner = workspace.owner
    s = get_user_settings(owner)
    if not s.portfolio_enabled:
        raise Http404("This portfolio is not available.")

    items = list(workspace.portfolio_items.filter(is_published=True))
    contact_email = s.reply_to or owner.email
    whatsapp = whatsapp_link(
        s.whatsapp_number,
        f"Hi {s.display_agency_name}, I saw your portfolio and would like to talk about a project.",
    )
    return render(request, 'portfolio/public.html', {
        'workspace': workspace,
        'owner': owner,
        'agency': s,
        'items': items,
        'industries': sorted({i.industry for i in items if i.industry}),
        'testimonials': [i for i in items if i.testimonial],
        'contact_email': contact_email,
        'whatsapp_url': whatsapp,
    })
