"""
Real lead discovery (no API key needed).

Pipeline
--------
1. Geocode the city with OpenStreetMap Nominatim  -> bounding box.
2. Ask the Overpass API for REAL businesses of the chosen industry inside that
   box that publish a website  -> candidate list (name, website, phone, ...).
3. Visit every candidate website. Dead / parked / unreachable sites are dropped.
4. For live sites, pull a public contact e-mail from the home page or the
   Contact page.
5. Save only live, non-duplicate businesses as Lead rows (source='OSM').

Nothing here is random or simulated. If OpenStreetMap has no data for a city /
industry, you simply get fewer (or zero) leads and a clear message.
"""
import re
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urlparse, urljoin

import requests
from bs4 import BeautifulSoup
from django.core.exceptions import ValidationError
from django.core.validators import validate_email
from django.utils import timezone

from .models import Lead

log = logging.getLogger(__name__)

NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
OVERPASS_URLS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
]

# Nominatim / Overpass ask clients to identify themselves.
API_HEADERS = {"User-Agent": "LeadRadarAI/1.0 (local business lead research tool)"}
# Business sites often block unknown bots, so look like a normal browser.
BROWSER_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Language": "en-US,en;q=0.8",
}

# Industry -> OpenStreetMap tag filters.
OSM_FILTERS = {
    "Restaurant": ['["amenity"~"^(restaurant|cafe|fast_food|food_court)$"]'],
    "Dental": ['["amenity"="dentist"]', '["healthcare"="dentist"]'],
    "Fitness": ['["leisure"~"^(fitness_centre|sports_centre)$"]'],
    "Real Estate": ['["office"="estate_agent"]'],
    "E-Commerce": ['["shop"]'],
    "Healthcare": ['["amenity"~"^(clinic|hospital|doctors)$"]', '["healthcare"~"^(clinic|hospital|doctor|centre)$"]'],
    "Legal": ['["office"~"^(lawyer|notary)$"]'],
    "Hospitality": ['["tourism"~"^(hotel|guest_house|hostel|motel|resort)$"]'],
    "Automotive": ['["shop"~"^(car|car_repair|car_parts|tyres)$"]'],
    "Home Services": ['["craft"~"^(plumber|electrician|carpenter|painter|hvac|roofer|builder)$"]'],
    "Manufacturing": ['["man_made"="works"]', '["industrial"]'],
    "Other": ['["office"="company"]'],
}

# These are "websites" in OSM but not the business's own site.
SOCIAL_DOMAINS = (
    "facebook.com", "instagram.com", "twitter.com", "x.com", "linkedin.com",
    "tiktok.com", "youtube.com", "wa.me", "whatsapp.com", "linktr.ee",
    "tripadvisor.", "google.com", "goo.gl", "maps.app",
)

PARKED_MARKERS = (
    "domain is for sale", "buy this domain", "this domain may be for sale",
    "domain parking", "parked free", "sedoparking", "hugedomains",
    "this domain has expired", "account suspended", "default web page",
)

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(?:\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}")
BAD_EMAIL_PARTS = ("sentry", "wixpress", "example.", "yourdomain", "domain.com", "email.com", "u003e", "noreply", "no-reply")
BAD_EMAIL_TLDS = {"png", "jpg", "jpeg", "gif", "webp", "svg", "css", "js", "woff", "woff2", "ico"}


class DiscoveryError(Exception):
    """Raised with a message that is safe to show to the user."""


# --------------------------------------------------------------------------
# Step 1 + 2: find real businesses
# --------------------------------------------------------------------------
def _geocode(city, country):
    if not city:
        raise DiscoveryError("Please enter a city (e.g. Lahore, Dubai, Karachi).")
    query = ", ".join(x for x in (city, country) if x)
    try:
        resp = requests.get(
            NOMINATIM_URL,
            params={"q": query, "format": "json", "limit": 1},
            headers=API_HEADERS,
            timeout=20,
        )
        data = resp.json()
    except (requests.RequestException, ValueError) as exc:
        raise DiscoveryError(f"Could not look up '{query}' on OpenStreetMap ({exc}). Check your internet and try again.")
    if not data:
        raise DiscoveryError(f"OpenStreetMap could not find '{query}'. Check the spelling of the city/country.")
    south, north, west, east = (float(x) for x in data[0]["boundingbox"])
    return south, west, north, east


def _build_query(industry, bbox, limit):
    s, w, n, e = bbox
    filters = OSM_FILTERS.get(industry) or OSM_FILTERS["Other"]
    parts = []
    for flt in filters:
        for website_key in ("website", "contact:website"):
            parts.append(f'nwr{flt}["name"]["{website_key}"]({s},{w},{n},{e});')
    return f"[out:json][timeout:60];({''.join(parts)});out tags center {limit};"


def _fetch_osm_elements(query):
    last_error = "unknown error"
    for url in OVERPASS_URLS:
        try:
            resp = requests.post(url, data={"data": query}, headers=API_HEADERS, timeout=90)
            if resp.status_code == 200:
                return resp.json().get("elements", [])
            last_error = f"HTTP {resp.status_code} from {urlparse(url).netloc}"
        except (requests.RequestException, ValueError) as exc:
            last_error = str(exc)
    raise DiscoveryError(
        f"The OpenStreetMap data server is busy or unreachable ({last_error}). Please try again in a minute."
    )


def _normalize_url(raw):
    raw = (raw or "").split(";")[0].strip()
    if not raw:
        return ""
    if not raw.lower().startswith(("http://", "https://")):
        raw = "https://" + raw
    parsed = urlparse(raw)
    host = parsed.netloc.lower()
    if "." not in host or " " in host:
        return ""
    if any(dom in host for dom in SOCIAL_DOMAINS):
        return ""
    url = raw if len(raw) <= 500 else f"{parsed.scheme}://{parsed.netloc}"
    return url


def _domain(url):
    host = urlparse(url).netloc.lower()
    return host[4:] if host.startswith("www.") else host


def _parse_element(el, industry, default_city, country):
    tags = el.get("tags") or {}
    name = (tags.get("name") or tags.get("name:en") or "").strip()
    website = _normalize_url(tags.get("website") or tags.get("contact:website") or tags.get("url"))
    if not name or not website:
        return None
    phone = (tags.get("phone") or tags.get("contact:phone") or "").split(";")[0].strip()[:50]
    email = (tags.get("email") or tags.get("contact:email") or "").split(";")[0].strip()
    return {
        "external_id": f"{el.get('type', 'node')}/{el.get('id')}",
        "business_name": name[:255],
        "website": website,
        "phone": phone,
        "osm_email": email,
        "city": (tags.get("addr:city") or default_city or "")[:100],
        "country": country,
        "industry": industry,
    }


# --------------------------------------------------------------------------
# Step 3: is the website really live?
# --------------------------------------------------------------------------
def check_website(url, timeout=8):
    """
    Visit `url`. Returns dict(live, status, final_url, html).
    live=True only if the server answered and the page looks like a real site
    (not parked / for sale). 401/403/429 count as live (site exists but blocks bots).
    """
    result = {"live": False, "status": 0, "final_url": url, "html": ""}
    attempts = [url]
    if url.startswith("https://"):
        attempts.append("http://" + url[len("https://"):])

    for target in attempts:
        try:
            resp = requests.get(target, headers=BROWSER_HEADERS, timeout=timeout, allow_redirects=True)
        except requests.RequestException:
            continue

        ctype = resp.headers.get("Content-Type", "").lower()
        html = resp.text[:400000] if ("html" in ctype or "text" in ctype or not ctype) else ""
        result.update(status=resp.status_code, final_url=resp.url, html=html)
        result["live"] = is_live_response(resp.status_code, html)
        return result
    return result


def is_live_response(status, html):
    if status in (401, 403, 429):
        return True
    if status >= 400 or status == 0:
        return False
    text = BeautifulSoup(html or "", "html.parser").get_text(" ", strip=True)
    if len(text) < 30:
        return False
    lowered = text[:3000].lower()
    return not any(marker in lowered for marker in PARKED_MARKERS)


# --------------------------------------------------------------------------
# Step 4: public contact e-mail
# --------------------------------------------------------------------------
def extract_emails(html):
    soup = BeautifulSoup(html or "", "html.parser")
    candidates = []
    for a in soup.find_all("a", href=True):
        href = a["href"].strip()
        if href.lower().startswith("mailto:"):
            candidates.append(href[7:].split("?")[0])
    candidates += EMAIL_RE.findall(soup.get_text(" "))
    candidates += EMAIL_RE.findall(html or "")

    clean, seen = [], set()
    for addr in candidates:
        addr = addr.strip().strip(".,;:<>()[]").lower()
        if not addr or addr in seen:
            continue
        seen.add(addr)
        if any(bad in addr for bad in BAD_EMAIL_PARTS):
            continue
        if addr.rsplit(".", 1)[-1] in BAD_EMAIL_TLDS:
            continue
        try:
            validate_email(addr)
        except ValidationError:
            continue
        clean.append(addr)
    return clean


def _best_email(emails, site_domain):
    for addr in emails:
        if addr.split("@", 1)[1].endswith(site_domain):
            return addr
    return emails[0] if emails else ""


def find_contact_email(base_url, html):
    site_domain = _domain(base_url)
    emails = extract_emails(html)
    if emails:
        return _best_email(emails, site_domain)

    # Try the Contact page once.
    soup = BeautifulSoup(html or "", "html.parser")
    for a in soup.find_all("a", href=True):
        label = (a.get_text(" ", strip=True) + " " + a["href"]).lower()
        if "contact" in label:
            contact_url = urljoin(base_url, a["href"])
            if _domain(contact_url) != site_domain:
                continue
            try:
                resp = requests.get(contact_url, headers=BROWSER_HEADERS, timeout=8)
                if resp.status_code < 400:
                    return _best_email(extract_emails(resp.text[:400000]), site_domain)
            except requests.RequestException:
                pass
            break
    return ""


def _enrich(candidate):
    """Runs in a worker thread: live-check one candidate and look for an e-mail."""
    check = check_website(candidate["website"])
    if not check["live"]:
        return candidate, None
    email = candidate.get("osm_email") or ""
    if not email:
        email = find_contact_email(check["final_url"], check["html"])
    return candidate, {"email": email, "final_url": check["final_url"]}


# --------------------------------------------------------------------------
# Public entry point
# --------------------------------------------------------------------------
def discover_real_leads(workspace, industry, country, city, count=10):
    """
    Find real, live businesses and save them as leads.
    Returns dict(created=[Lead,...], candidates=int, dead=int, duplicates=int).
    """
    try:
        count = max(1, min(int(count), 50))
    except (TypeError, ValueError):
        count = 10
    industry = industry if industry in OSM_FILTERS else "Other"

    bbox = _geocode(city, country)
    candidate_limit = min(count * 6, 300)
    elements = _fetch_osm_elements(_build_query(industry, bbox, candidate_limit))

    existing_ids = set(
        Lead.objects.filter(workspace=workspace).exclude(external_id="").values_list("external_id", flat=True)
    )
    existing_domains = {
        _domain(w) for w in Lead.objects.filter(workspace=workspace).exclude(website="").values_list("website", flat=True)
    }

    candidates, duplicates, seen_domains = [], 0, set()
    for el in elements:
        cand = _parse_element(el, industry, city, country)
        if not cand:
            continue
        dom = _domain(cand["website"])
        if cand["external_id"] in existing_ids or dom in existing_domains or dom in seen_domains:
            duplicates += 1
            continue
        seen_domains.add(dom)
        candidates.append(cand)

    created, dead = [], 0
    if candidates:
        pool = ThreadPoolExecutor(max_workers=8)
        try:
            futures = [pool.submit(_enrich, c) for c in candidates]
            for fut in as_completed(futures):
                try:
                    cand, info = fut.result()
                except Exception:  # one bad site must never stop the run
                    log.exception("discovery: enrich failed")
                    dead += 1
                    continue
                if info is None:
                    dead += 1
                    continue
                created.append(
                    Lead.objects.create(
                        workspace=workspace,
                        business_name=cand["business_name"],
                        website=info["final_url"] if len(info["final_url"]) <= 500 else cand["website"],
                        email=info["email"],
                        phone=cand["phone"],
                        city=cand["city"],
                        country=cand["country"],
                        industry=cand["industry"],
                        source="OSM",
                        status="NEW",
                        external_id=cand["external_id"],
                        is_website_live=True,
                        website_checked_at=timezone.now(),
                    )
                )
                if len(created) >= count:
                    break
        finally:
            pool.shutdown(wait=False, cancel_futures=True)

    return {
        "created": created,
        "candidates": len(candidates),
        "dead": dead,
        "duplicates": duplicates,
    }
